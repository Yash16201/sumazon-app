import React from 'react'

const FooterBar = () => {
  return (
    <></>
  )
}

export default FooterBar